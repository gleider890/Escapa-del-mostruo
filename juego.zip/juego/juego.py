import pygame
import random
import sys
import math

# ------------------------------
# Configuración e inicialización
# ------------------------------
pygame.init()
ANCHO, ALTO = 600, 400
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Escapa del Monstruo - Modos + Jefe")
clock = pygame.time.Clock()

# Colores
NEGRO   = (0, 0, 0)
AZUL    = (0, 0, 255)
ROJO    = (255, 0, 0)
VERDE   = (0, 255, 0)
BLANCO  = (255, 255, 255)
AMARILLO= (255, 255, 0)

fuente = pygame.font.SysFont("Arial", 24)

# ------------------------------
# Parámetros de juego
# ------------------------------
# Jugador
JUG_TAM   = 30
VEL_JUG   = 5
jugador   = pygame.Rect(ANCHO//2 - JUG_TAM//2, ALTO//2 - JUG_TAM//2, JUG_TAM, JUG_TAM)

# Enemigos normales
enemigos = []
ENEM_TAM = 26

# Dificultades (normales)
dificultades = {
    "FACIL":  {"vel_enem": 2, "freq": 45},   # cada 45 frames spawnea
    "MEDIO":  {"vel_enem": 3, "freq": 25},
    "DIFICIL":{"vel_enem": 4, "freq": 15}
}
dificultad_actual = "MEDIO"

# Sistema de puntos y vidas
puntos = 7540
vidas  = 1
invulnerable_frames = 0  # frames de invulnerabilidad tras golpe

# ------------------------------
# Parámetros de Jefe
# ------------------------------
boss_activo = False
boss_rect   = None
boss_vel    = 2.2    # velocidad base (se escalará al reaparecer)
boss_size   = 100    # tamaño base (se escalará al reaparecer)
boss_balas  = []     # cada bala: {"x":float,"y":float,"w":int,"h":int,"vx":float,"vy":float}
BALA_VEL    = 5.0
boss_cooldown = 0
BOSS_CD_DISPARO = 35   # frames entre disparos

# Apariciones del boss
BOSS_PRIMER_INICIO = 8000
BOSS_DURACION_PTS  = 2000   # activo desde start hasta start+2000 (ej: 8000-10000)
BOSS_DESCANSO_PTS  = 3000   # reaparece 3000 pts después de desaparecer (ej: 10000->13000)
boss_next_start    = BOSS_PRIMER_INICIO
boss_end_at        = None
boss_veces_visto   = 0      # para escalar tamaño/vel en reapariciones

# ------------------------------
# Utilidades
# ------------------------------
def mostrar_texto(texto, x, y, color=BLANCO):
    s = fuente.render(texto, True, color)
    pantalla.blit(s, (x, y))

def crear_enemigo():
    x = random.randint(0, ANCHO - ENEM_TAM)
    y = -ENEM_TAM
    return pygame.Rect(x, y, ENEM_TAM, ENEM_TAM)

def mover_enemigos(lista, vel):
    for e in lista:
        e.y += vel
    # Limpiar fuera de pantalla
    lista[:] = [e for e in lista if e.top <= ALTO]

def hay_colision_con_lista(rect, lista):
    for e in lista:
        if rect.colliderect(e):
            return True
    return False

def normaliza(dx, dy):
    mag = math.hypot(dx, dy)
    if mag == 0:
        return 0.0, 0.0
    return dx/mag, dy/mag

def spawn_bala_dirigida(origen_rect, objetivo_rect, vel=BALA_VEL):
    ox, oy = origen_rect.centerx, origen_rect.centery
    tx, ty = objetivo_rect.centerx, objetivo_rect.centery
    dx, dy = normaliza(tx - ox, ty - oy)
    return {"x": ox-4, "y": oy-4, "w": 8, "h": 8, "vx": dx*vel, "vy": dy*vel}

def mover_balas(balas):
    for b in balas:
        b["x"] += b["vx"]
        b["y"] += b["vy"]
    # Limpiar balas fuera
    balas[:] = [b for b in balas if -20 <= b["x"] <= ANCHO+20 and -20 <= b["y"] <= ALTO+20]

def rect_de_bala(b):
    return pygame.Rect(int(b["x"]), int(b["y"]), b["w"], b["h"])

def boss_aparece():
    """Activa al jefe, limpia enemigos normales y crea su rect con tamaño/vel actuales."""
    global boss_activo, boss_rect, boss_balas, boss_cooldown
    boss_activo = True
    enemigos.clear()
    boss_balas.clear()
    x = ANCHO//2 - boss_size//2
    y = ALTO//4 - boss_size//2
    boss_rect = pygame.Rect(x, y, int(boss_size), int(boss_size))
    boss_cooldown = BOSS_CD_DISPARO

def boss_desaparece():
    """Desactiva al jefe y otorga una vida extra."""
    global boss_activo, vidas
    boss_activo = False
    vidas += 1

def boss_perseguir(boss_rect, objetivo_rect, vel):
    # Mover en X hacia el jugador
    if boss_rect.centerx < objetivo_rect.centerx:
        boss_rect.x += vel
    elif boss_rect.centerx > objetivo_rect.centerx:
        boss_rect.x -= vel
    # Mover en Y hacia el jugador
    if boss_rect.centery < objetivo_rect.centery:
        boss_rect.y += vel
    elif boss_rect.centery > objetivo_rect.centery:
        boss_rect.y -= vel
    # Mantener dentro de pantalla
    boss_rect.clamp_ip(pantalla.get_rect())

def procesar_golpe():
    """Gestiona pérdida de vida o game over. Devuelve True si game over."""
    global vidas, invulnerable_frames
    if invulnerable_frames > 0:
        return False
    if vidas > 0:
        vidas -= 1
        # invulnerabilidad y "reseteo suave" del jugador
        invulnerable_frames = 60
        # Reubicar al centro
        jugador.x, jugador.y = ANCHO//2 - JUG_TAM//2, ALTO//2 - JUG_TAM//2
        return False
    else:
        return True

# ------------------------------
# Menús
# ------------------------------
def menu_inicio():
    global dificultad_actual, puntos, vidas
    while True:
        pantalla.fill(NEGRO)
        mostrar_texto("ESCAPA DEL MONSTRUO", 160, 80, BLANCO)
        mostrar_texto("Selecciona dificultad:", 180, 130)
        mostrar_texto("1) FACIL   2) MEDIO   3) DIFICIL", 120, 165, AMARILLO)
        mostrar_texto("ESPACIO para empezar  |  Q para salir", 110, 205)
        mostrar_texto(f"Vidas iniciales: 1", 220, 240)
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_1: dificultad_actual = "FACIL"
                if e.key == pygame.K_2: dificultad_actual = "MEDIO"
                if e.key == pygame.K_3: dificultad_actual = "DIFICIL"
                if e.key == pygame.K_q: pygame.quit(); sys.exit()
                if e.key == pygame.K_SPACE:
                    puntos = 0
                    vidas  = 1
                    return

def menu_pausa(puntos):
    while True:
        pantalla.fill(NEGRO)
        mostrar_texto("PAUSA", 270, 100, BLANCO)
        mostrar_texto(f"Puntos: {puntos}", 240, 135, BLANCO)
        mostrar_texto("R) Reanudar", 210, 180)
        mostrar_texto("N) Reiniciar", 210, 210)
        mostrar_texto("M) Menu principal", 210, 240)
        pygame.display.flip()
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r: return "reanudar"
                if e.key == pygame.K_n: return "reiniciar"
                if e.key == pygame.K_m: return "menu"

def game_over_menu(puntos):
    while True:
        pantalla.fill(NEGRO)
        mostrar_texto("GAME OVER", 235, 100, ROJO)
        mostrar_texto(f"Puntos: {puntos}", 240, 135, BLANCO)
        mostrar_texto("R) Reiniciar   M) Menu   Q) Salir", 140, 180)
        pygame.display.flip()
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r: return "reiniciar"
                if e.key == pygame.K_m: return "menu"
                if e.key == pygame.K_q: pygame.quit(); sys.exit()

# ------------------------------
# Bucle principal de una partida
# ------------------------------
def main():
    global puntos, invulnerable_frames
    global boss_activo, boss_next_start, boss_end_at, boss_veces_visto, boss_vel, boss_size

    # Reset por partida
    enemigos.clear()
    boss_activo = False
    boss_balas.clear()
    boss_next_start = BOSS_PRIMER_INICIO
    boss_end_at = None
    boss_veces_visto = 0
    boss_vel = 2.2
    boss_size = 100
    invulnerable_frames = 0

    jugador.x, jugador.y = ANCHO//2 - JUG_TAM//2, ALTO//2 - JUG_TAM//2

    vel_enem = dificultades[dificultad_actual]["vel_enem"]
    freq_enem = dificultades[dificultad_actual]["freq"]
    frame_spawn = 0

    while True:
        clock.tick(60)
        pantalla.fill(NEGRO)

        # Eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_p:
                    act = menu_pausa(puntos)
                    if act == "reanudar":
                        pass
                    elif act == "reiniciar":
                        return "reiniciar"
                    elif act == "menu":
                        return "menu"

        teclas = pygame.key.get_pressed()

        # Movimiento jugador
        movido = False
        if teclas[pygame.K_LEFT] and jugador.left > 0:
            jugador.x -= VEL_JUG; movido = True
        if teclas[pygame.K_RIGHT] and jugador.right < ANCHO:
            jugador.x += VEL_JUG; movido = True
        if teclas[pygame.K_UP] and jugador.top > 0:
            jugador.y -= VEL_JUG; movido = True
        if teclas[pygame.K_DOWN] and jugador.bottom < ALTO:
            jugador.y += VEL_JUG; movido = True

        # Puntos solo si se mueve
        if movido:
            puntos += 1

        # Invulnerabilidad decremento
        if invulnerable_frames > 0:
            invulnerable_frames -= 1

        # Aparición/desaparición del jefe según puntos
        if not boss_activo and puntos >= boss_next_start:
            # Escalar (no la primera vez)
            if boss_veces_visto > 0:
                boss_size = int(boss_size * 1.10)
                boss_vel *= 1.15
            boss_aparece()
            boss_end_at = boss_next_start + BOSS_DURACION_PTS
            boss_veces_visto += 1

        if boss_activo and puntos >= boss_end_at:
            boss_desaparece()
            boss_activo = False
            # Programar próxima aparición: end + descanso
            boss_next_start = boss_end_at + BOSS_DESCANSO_PTS
            boss_end_at = None

        # Lógica de enemigos / jefe
        if boss_activo:
            # Solo jefe: no spawnear enemigos normales
            # Mover jefe persiguiendo
            boss_perseguir(boss_rect, jugador, boss_vel)

            # Disparo dirigido
            if boss_cooldown > 0:
                boss_cooldown -= 1
            else:
                boss_balas.append(spawn_bala_dirigida(boss_rect, jugador, BALA_VEL))
                # A veces dispara doble para presión
                if random.random() < 0.20:
                    boss_balas.append(spawn_bala_dirigida(boss_rect, jugador, BALA_VEL+1.2))
                # reset cooldown
                # más rápido si el jefe es más veloz
                cd = max(12, int(BOSS_CD_DISPARO - (boss_vel-2.2)*4))
                # pequeño jitter
                boss_cooldown = cd + random.randint(-3, 3)

            mover_balas(boss_balas)

            # Colisiones con jefe/balas
            golpe = False
            # Choque directo con el jefe
            if boss_rect.colliderect(jugador):
                golpe = True
            else:
                # Balas
                for b in boss_balas:
                    if rect_de_bala(b).colliderect(jugador):
                        golpe = True
                        break

            if golpe:
                if procesar_golpe():
                    return game_over_menu(puntos)

        else:
            # Fase normal: spawnear y mover enemigos
            frame_spawn += 1
            if frame_spawn >= freq_enem:
                enemigos.append(crear_enemigo())
                frame_spawn = 0
            mover_enemigos(enemigos, vel_enem)

            # Colisión con enemigos normales
            if hay_colision_con_lista(jugador, enemigos):
                if procesar_golpe():
                    return game_over_menu(puntos)

        # ------------------------------
        # Dibujo
        # ------------------------------
        # Jugador (parpadeo si invulnerable)
        dibujar_jugador = True
        if invulnerable_frames > 0 and (invulnerable_frames // 5) % 2 == 0:
            dibujar_jugador = False
        if dibujar_jugador:
            pygame.draw.rect(pantalla, AZUL, jugador)

        # Enemigos normales
        if not boss_activo:
            for e in enemigos:
                pygame.draw.rect(pantalla, ROJO, e)
        else:
            # Boss + balas
            pygame.draw.rect(pantalla, VERDE, boss_rect)
            for b in boss_balas:
                pygame.draw.rect(pantalla, ROJO, rect_de_bala(b))

        # HUD
        mostrar_texto(f"Puntos: {puntos}", 10, 8, BLANCO)
        mostrar_texto(f"Vidas: {vidas}",  10, 32, BLANCO)
        if boss_activo:
            mostrar_texto("JEFE!", ANCHO-90, 8, AMARILLO)
        else:
            mostrar_texto(f"Modo: {dificultad_actual}", ANCHO-180, 8, BLANCO)

        pygame.display.flip()

# ------------------------------
# Loop del juego
# ------------------------------
while True:
    menu_inicio()
    accion = main()
    if accion == "menu":
        continue
    if accion == "reiniciar":
        continue